SELECT * FROM public.film
ORDER BY rental_rate DESC 