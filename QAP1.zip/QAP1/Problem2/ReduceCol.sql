SELECT film_id, title, Description
FROM film
ORDER BY film_id ASC 