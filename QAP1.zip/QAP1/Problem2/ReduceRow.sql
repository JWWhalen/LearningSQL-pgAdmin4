SELECT * 
FROM public.film
WHERE rating = 'R';
