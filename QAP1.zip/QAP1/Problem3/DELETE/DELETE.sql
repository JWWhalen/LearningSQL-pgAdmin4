DELETE FROM address
WHERE address = '123 Murphy street' AND district = 'Bell Island';
