SELECT * FROM public.address
ORDER BY address_id DESC 

-- 606, 123 murphy street, Bell Island.