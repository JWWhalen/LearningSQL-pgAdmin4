SELECT * FROM public.customer
ORDER BY store_id ASC, last_name DESC 

-- Family last name Whalen. Store id of 1.